export default function ScrapMyCar() {
  return (
    <div className="p-8">
      <h1 className="text-3xl font-bold">Scrap My Car</h1>
      <p className="mt-4">
        Get an instant offer for your scrap car anywhere in the UK!
      </p>
    </div>
  );
}
