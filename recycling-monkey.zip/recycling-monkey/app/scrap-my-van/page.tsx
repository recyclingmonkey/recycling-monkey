import Image from "next/image";

export default function Home() {
  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-gray-50 p-8">
      <div className="max-w-7xl w-full flex flex-col-reverse md:flex-row items-center gap-8">
        {/* LEFT SIDE */}
        <div className="flex-1 text-center md:text-left">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">
            Sell Your Scrap Car in the UK
          </h1>
          <p className="text-lg mb-6">
            Get an instant offer for your car and free collection anywhere in
            the UK.
          </p>

          <div className="bg-yellow-300 p-4 rounded-md flex flex-col md:flex-row items-center gap-2">
            <input
              type="text"
              placeholder="Enter Reg"
              className="px-4 py-2 border border-gray-300 rounded-md w-full md:w-60"
            />
            <input
              type="text"
              placeholder="Contact Number"
              className="px-4 py-2 border border-gray-300 rounded-md w-full md:w-60"
            />
            <input
              type="text"
              placeholder="Postcode"
              className="px-4 py-2 border border-gray-300 rounded-md w-full md:w-60"
            />
            <button className="bg-green-600 text-white px-6 py-2 rounded-md w-full md:w-auto">
              Get My Instant Quote
            </button>
          </div>
        </div>

        {/* RIGHT SIDE */}
        <div className="flex-1">
          <Image
            src="https://images.unsplash.com/photo-1599901158855-c1f36bfae9d0?auto=format&fit=crop&w=800&q=80"
            alt="Recycling Truck"
            width={500}
            height={400}
            className="rounded-md"
          />
        </div>
      </div>
    </div>
  );
}
