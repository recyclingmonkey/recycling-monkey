export default function AreasWeCover() {
  return (
    <div className="p-8">
      <h1 className="text-3xl font-bold">Areas We Cover</h1>
      <p className="mt-4">We collect vehicles nationwide.</p>
    </div>
  );
}
